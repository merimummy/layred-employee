package com.cg.empmgm.ui;

import java.util.ArrayList;
import java.util.Scanner;

import com.cg.empmgm.bean.Employee;
import com.cg.empmgm.exception.EmployeeException;
import com.cg.empmgm.service.EmpService;
import com.cg.empmgm.service.EmpServiceImpl;

public class EmpClient 
{
    static Scanner sc=null;
    static EmpService empSer=null;
    public static void main(String[] args)
    {
        empSer=new EmpServiceImpl();
        sc=new Scanner(System.in);
        int choice=0;
        while(true)
        {
            System.out.println("What Do U Want To Do?");
            System.out.println("1:Add Emp\t 2:Fetch All Emp\t 3:Delete Emp\t 4:Update Emp\t 5:Exit");
            choice=sc.nextInt();
            switch(choice)
            {
            case 1:insertEmp();
                   break;
            case 2:fetchAllEmp();
                    break;
            case 3:delEmp();
                    break;
            case 4:updateEmp();
                    break;
            default:System.exit(0);
            }
        }

    }
    public static void insertEmp()
    {
        System.out.println("Enter EmpName: ");
        String enm=sc.next();
        float esl=0.0F;
        try
        {
         if(empSer.validateName(enm))
          {
            System.out.println("Enter Salary :");
            esl=sc.nextFloat();
            Employee ee=new Employee();
            ee.setEmpName(enm);
            ee.setEmpSal(esl);
            int dataAdded=empSer.addEmp(ee);
            if(dataAdded==1)
            {
                System.out.println("Emp Data Added:");
            }
            else
            {
                System.out.println("May be Some Exception while addition");
            }
           }
        }
        catch(EmployeeException e)
        {
            System.out.println(e.getMessage());
        }
    }
    public static void fetchAllEmp()
    {
        try 
        {
            ArrayList<Employee> empList=empSer.getAllEmp();
            for(Employee ee:empList)
            {
                System.out.println(ee);
            }
        } 
        catch (EmployeeException e)
        {
            System.out.println("May be Some Exception while fetching");
            e.printStackTrace();
        }
    }
    public static void delEmp()
    {
        
    }
    public static void updateEmp()
    {
        
    }
}
